const Header = () => {
    return <h1>My Header in another component</h1>;
  };
  
  export default Header;