const Footer = () => {
    return <h3>My Footer in another component</h3>;
  };
  
  export default Footer;